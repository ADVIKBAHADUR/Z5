#ifndef ALPHA_H
#define ALPHA_H
#include "Coord.h"


extern const Coord az_a[9];
extern const Coord az_b[9];
extern const Coord az_c[9];
extern const Coord az_d[9];
extern const Coord az_e[9];
extern const Coord az_f[9 ];
extern const Coord az_g[9];
extern const Coord az_h[9];
extern const Coord az_i[9];
extern const Coord az_j[9];
extern const Coord az_k[9];
extern const Coord az_l[9];
extern const Coord az_m[9];
extern const Coord az_n[9];
extern const Coord az_o[9];
extern const Coord az_p[9];
extern const Coord az_q[9];
extern const Coord az_r[9];
extern const Coord az_s[9];
extern const Coord az_t[9];
extern const Coord az_u[9];
extern const Coord az_v[9];
extern const Coord az_w[9];
extern const Coord az_x[9];
extern const Coord az_y[9];
extern const Coord az_z[9];

#endif