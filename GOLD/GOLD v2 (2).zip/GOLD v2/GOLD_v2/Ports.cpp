#include "Ports.h"

const int LEYE = 9; 
const int REYE = 3; 
const int V_RIGHT = 19;
const int V_LEFT = 16; 
const int S_RIGHT1 = 7;
const int S_RIGHT2 =8; 
const int S_LEFT1 = 2; 
const int S_LEFT2 = 10;
const int US_TRIG = 6;
const int US_ECHO = 5;
const unsigned long EVENT = 30000;//unsigned as gets realy long
const int STOPPINGDIST = 30;
unsigned long prev_event = 0;
const int fasterwheel = 100;
const int slowerwheel = 20;

